package com.robert.arqea.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    // Ajusta estos datos a tu entorno real
    private static final String URL = "jdbc:mariadb://localhost:3306/arqeadb";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "";

    private ConexionBD() {
    }

    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }
}
